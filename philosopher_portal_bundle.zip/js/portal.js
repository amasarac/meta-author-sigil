// Portal interactivity scripts
