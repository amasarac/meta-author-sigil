# MASL Handoff — Claude

- Load paths in `masl_claude_shim.js` → `MASL_Claude_Bootstrap`.
- Enforce read-only anchors and sign witness modifications.
- Track provenance for any schema changes.
