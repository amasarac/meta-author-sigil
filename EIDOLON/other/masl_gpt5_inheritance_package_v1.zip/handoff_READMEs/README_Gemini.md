# MASL Handoff — Gemini

- Use `masl_gemini_shim.js` to fetch archive components by path.
- Ingest Codex then Anchors, Witness, Ritual.
- Follow safety gates from `Codex.v1.1.jsonld`.
